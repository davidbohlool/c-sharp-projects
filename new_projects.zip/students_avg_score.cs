﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // محاسبه میانگین نمرات دانشجوها
            int student, i = 1, lecture, j = 1;
            double total_score = 0.00, total_unit = 0.00, avg, score, unit;
            Console.WriteLine("How many students?");
            student = int.Parse(Console.ReadLine());
            while (i <= student)
            {
                Console.WriteLine("Student " + i + ": How many lectures?");
                lecture = int.Parse(Console.ReadLine());
                while (j <= lecture)
                {
                    Console.WriteLine("Lecture " + j + ": What is score?");
                    score = float.Parse(Console.ReadLine());
                    Console.WriteLine("How many unit?");
                    unit = float.Parse(Console.ReadLine());
                    total_unit += unit;
                    total_score += score * unit;
                    j++;
                }
                j = 1;
                i++;
            }
            avg = total_score / total_unit;
            Console.WriteLine("Avg is: " + avg);
            Console.WriteLine("press any key to exit...");
            Console.ReadKey();
        }
    }
}