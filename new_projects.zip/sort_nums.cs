﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // دریافت چهار عدد از ورودی مرتب کردن از کوچک به بزرگ و نمایش میانه
            double a,b,c,d,med, i=1, temp;
            Boolean change = true;

            Console.WriteLine("Enter 4 nums:");
            a = int.Parse(Console.ReadLine());
            b = int.Parse(Console.ReadLine());
            c = int.Parse(Console.ReadLine());
            d = int.Parse(Console.ReadLine());

            while (change)
            {
                change = false;
                if (a > b )
                {
                    temp = a;
                    a = b;
                    b = temp;
                    change = true;
                }
                if (b > c)
                {
                    temp = b;
                    b = c;
                    c = temp;
                    change = true;
                }
                if (c > d)
                {
                    temp = c;
                    c = d;
                    d = temp;
                    change = true;
                }
            }

            med = (b + c) / 2;

            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);


            Console.WriteLine("Median is: " + med);
            Console.WriteLine("press any key to exit...");
            Console.ReadKey();
        }
    }
}