﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // محاسبه سود فاکتور
            int product, i = 1 ;
            double profit, price, sum = 0.00,quantity;

            Console.WriteLine("How many product?");
            product = int.Parse(Console.ReadLine());

            while (i <= product)
            {
                Console.WriteLine("How much?");
                price = float.Parse(Console.ReadLine());
                Console.WriteLine("How many?");
                quantity = int.Parse(Console.ReadLine());
                sum = sum + (price * quantity);
                i++;
            }

            profit = sum * 12/100;
            Console.WriteLine("Profit is: " + profit);
            Console.WriteLine("press any key to exit...");
            Console.ReadKey();
        }
    }
}